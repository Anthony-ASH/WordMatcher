﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordUnscrambler.Classes;
using WordUnscrambler.Data;

namespace WordUnscrambler
{
    class Program
    {
        private static readonly FileReader _fileRead = new FileReader();
        private static readonly WordMatcher _wordMatcher = new WordMatcher();


        static void Main(string[] args)
        {

            try
            {

                bool continueWordUnscramble = true;

                do
                {
                    Console.WriteLine(Constants.OpeningOptions);
                    var option = Console.ReadLine() ?? string.Empty;

                    switch (option.ToUpper())
                    {
                        case Constants.File:
                            Console.Write(Constants.AskForFile);
                            ExecuteFileScenario();
                            break;
                        case Constants.Manual:
                            Console.Write(Constants.AskForManual);
                            ExecuteManualScenario();
                            break;
                        default:
                            Console.Write(Constants.OptionsUnrecognized);
                            break;

                    }

                    var continueDecision = string.Empty;
                    do
                    {

                        Console.WriteLine(Constants.ContinueProgram);
                        continueDecision = Console.ReadLine() ?? string.Empty;

                    } while (!continueDecision.Equals(Constants.Yes, StringComparison.OrdinalIgnoreCase) &&
                             !continueDecision.Equals(Constants.No, StringComparison.OrdinalIgnoreCase));

                    continueWordUnscramble = continueDecision.Equals(Constants.Yes, StringComparison.OrdinalIgnoreCase);

                } while (continueWordUnscramble);

            } 
            catch (Exception ex)
            {
                Console.WriteLine(Constants.ProgramEnd + ex.Message);
            }


        }

        private static void ExecuteManualScenario()
        {
            var manualInput = Console.ReadLine() ?? string.Empty;
            string[] scrambledWords = manualInput.Split(',');
            DisplayUnscrambled(scrambledWords);


        }


        private static void ExecuteFileScenario()
        {

            try
            {

                var fileName = Console.ReadLine() ?? string.Empty;
                string[] scrambledWords = _fileRead.Read(fileName);
                DisplayUnscrambled(scrambledWords);

            } catch (Exception ex) {
                
                Console.WriteLine(Constants.ErrorScreen + ex.Message);
            }

        }

        private static void DisplayUnscrambled(string[] scrambledWords)
        {

            string[] wordList = _fileRead.Read(Constants.WordListFile);

            List<MatchedWord> matchedWords = _wordMatcher.Match(scrambledWords, wordList);

            if (matchedWords.Any())
            {
                foreach (var matches in matchedWords)
                {
                    Console.WriteLine(Constants.MatchFound, matches.ScrambledWord, matches.Word);
                }
            }
            else
            {
                Console.WriteLine(Constants.MatchNotFound);
            }

        }
    }
}