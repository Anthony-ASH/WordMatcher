﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WordUnscrambler.Classes
{
    class FileReader
    {
        public string[] Read(string wordListFile)
        {
            
            string[] fileContents;

            try
            {

                fileContents = File.ReadAllLines(wordListFile);

            } catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return fileContents;

        }
    }
}
