﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using WordUnscrambler.Data;

namespace WordUnscrambler.Classes
{
    class WordMatcher
    {
        public List<MatchedWord> Match(string[] scrambledWords, string[] wordList)
        {
            var matchedWords = new List<MatchedWord>();

            foreach(var word in scrambledWords)
            {

                foreach (var word2 in wordList)
                {
                    if (word.Equals(word2, StringComparison.OrdinalIgnoreCase))
                    {

                        matchedWords.Add(BuildMatches(word, word2));

                    }

                    else
                    {
                        var scrambleArray = word.ToCharArray();
                        var wordArray = word2.ToCharArray();

                        Array.Sort(scrambleArray);
                        Array.Sort(wordArray);

                        var sortedScrambled = new string(scrambleArray);
                        var sortedWord = new string(wordArray);

                        if (sortedScrambled.Equals(sortedWord, StringComparison.OrdinalIgnoreCase))
                        {

                            matchedWords.Add(BuildMatches(word, word2));

                        }
                    }

                }

            }


            return matchedWords;

        }

        private MatchedWord BuildMatches(string scrambleWords, string word)
        {
            MatchedWord matchedWord = new MatchedWord()
            {
                ScrambledWord = scrambleWords,
                Word = word
            };

            return matchedWord;

        }
    }
}
