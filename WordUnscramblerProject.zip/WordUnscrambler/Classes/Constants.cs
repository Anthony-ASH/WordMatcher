﻿namespace WordUnscrambler.Classes
{
    class Constants
    {

        public const string OpeningOptions = "Would you like to input your scrambled word(s) manually or as a file: please press F (file) | M (manual)";
        public const string ContinueProgram = "Would you like to continue? please press Y (yes) | N (no)";
        
        public const string AskForFile = "Please enter full file path, including the file name: ";
        public const string AskForManual = "Enter word(s) manually (use commas for seperation of multiple): ";
        public const string OptionsUnrecognized = "Not a valid option.";
        
        public const string ErrorScreen = "Couldnt lead scrambled words due to error: ";
        public const string ProgramEnd = "The program will be terminated.";
       
        public const string MatchFound = "MATCH FOUND FOR {0}: {1}";
        public const string MatchNotFound = "NO MATCHES WERE FOUND.";

        public const string Yes = "Y"; 
        public const string No = "N";
        public const string File = "F";
        public const string Manual = "M";

        public const string WordListFile = "wordlist.txt";

    }
}
