﻿namespace WordUnscrambler.Data
{
    struct MatchedWord
    {

        public string ScrambledWord {  get; set; }
        public string Word { get; set; }

    }
}
